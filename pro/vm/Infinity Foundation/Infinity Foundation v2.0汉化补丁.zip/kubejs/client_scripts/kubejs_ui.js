onEvent('ui.main_menu', event => {
  event.replace(ui => {
    ui.background('ifdata:textures/panorama_overlay.png')
    ui.minecraftLogo(20)

    ui.label(l => {
      l.name = Text.aqua('整合包制作:Rovenne 译者:自尊寺')
      l.x = (ui.width - l.width) / 2
      l.y = 60
      l.shadow = true
    })

    ui.button(b => {
      b.name = '退出计划'
      b.x = 10
      b.y = ui.height - b.height - 10
      b.action = 'minecraft:quit'
    })
    
    ui.button(b => {
      b.name = '计划设置'
      b.x = 10
      b.y = ui.height - b.height - 40
      b.action = 'minecraft:options'
    })
    
    ui.button(b => {
      b.name = '团体计划'
      b.x = 10
      b.y = ui.height - b.height - 70
      b.action = 'minecraft:multiplayer'
    })
    
    ui.button(b => {
      b.name = '独行计划'
      b.x = 10
      b.y = ui.height - b.height - 100
      b.action = 'minecraft:singleplayer'
    })

  })
})