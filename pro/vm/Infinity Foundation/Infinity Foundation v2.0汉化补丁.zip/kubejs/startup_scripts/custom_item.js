onEvent('item.registry', event => {
event.create('fp_research').displayName('罐中之脑').tooltip("消耗以解锁所有的飞向未来的研究"),
event.create('parts').displayName('机械零件'),
event.create('infinity').displayName('无限').glow(true).tooltip("右键单击以完成整合包!"),
event.create('hot_bucket').displayName('热水桶').unstackable(),
event.create('moist_bucket').displayName('湿气桶').unstackable(),
event.create('mystic_flower').displayName('神秘花'),
event.create('false_copper').displayName('伪铜'),
event.create('false_tin').displayName('假锡'),
event.create('rubberduck').displayName('橡皮鸭'),
event.create('wish').displayName('愿望').tooltip("右键点击，让你的梦想成真!"),
event.create('rift_creator').displayName('裂缝创造者'),
event.create('prismatic_shard').displayName('五彩碎片'),
event.create('soul1').displayName('龙魂'),
event.create('soul2').displayName('精灵灵魂'),
event.create('soul3').displayName('守卫者灵魂'),
event.create('soul4').displayName('莎布·尼古拉丝灵魂')
})