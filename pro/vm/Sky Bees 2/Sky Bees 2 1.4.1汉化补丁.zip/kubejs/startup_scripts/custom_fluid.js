// New Fluids
events.listen('fluid.registry', event => {

event.create('molten_valdanium').textureThick(0x21004E).displayName('熔融瓦尔达尼姆').bucketColor(0x21004E)
event.create('molten_starlight_iron').textureThick(0xDFE1E2).displayName('熔融星光闪耀的铁').bucketColor(0xDFE1E2)
event.create('molten_manainfused_coal').textureThick(0x204C52).displayName('熔融蕴魔煤炭').bucketColor(0x204C52)
event.create('organic_water').textureThin(0x4D9349).displayName('有机水').bucketColor(0x4D9349)


})
