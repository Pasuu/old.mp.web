events.listen('block.registry', event => {


event.create('valdanium_block').material('iron').hardness(50).displayName('瓦尔达尼姆块').requiresTool(true)
event.create('seed_ore').material('stone').hardness(2.0).displayName('种子矿石').requiresTool(true)
event.create('starlight_iron').material('stone').hardness(2.0).displayName('星光闪耀的铁块').requiresTool(true)
event.create('manainfused_coal').material('stone').hardness(2.0).displayName('蕴魔煤炭').requiresTool(true)
event.create('dna_spawner').material('stone').hardness(2.0).displayName('DNA 刷怪笼').requiresTool(true).defaultCutout()





})
