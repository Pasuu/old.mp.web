/// priority: 0

console.info('Hello, World! (You will only see this line once in console, during startup)')

// New Items
onEvent('item.registry', event => {

event.create('caveopolis:ore_extractor_upgrade_base').displayName('矿石提练升级：基础')
event.create('caveopolis:ore_extractor_upgrade_tier_1').displayName('矿石提练升级：级别1')
event.create('caveopolis:ore_extractor_upgrade_tier_2').displayName('矿石提练升级：级别2')
event.create('caveopolis:ore_extractor_upgrade_tier_3').displayName('矿石提练升级：级别3')
event.create('caveopolis:ore_extractor_upgrade_tier_4').displayName('矿石提练升级：级别4')
event.create('caveopolis:ore_extractor_upgrade_blazing').displayName('矿石提练升级：烈焰')

event.create('caveopolis:withering_dust').displayName('凋零尘')
event.create('caveopolis:soulsteel_ingot').displayName('灵魂钢锭')

event.create('caveopolis:menu').displayName('世界菜单').displayName('Caveopolis 菜单').texture(`minecraft:item/paper`).color(0, 0x373737).maxStackSize(1)

event.create('caveopolis:color_crystal').displayName('色彩水晶').glow(true)
event.create('caveopolis:dragon_core').displayName('龙核').glow(true)
event.create('caveopolis:ultimate_shard').displayName('终极碎片').glow(true)
event.create('caveopolis:ingot_of_ingots').displayName('锭中之锭').glow(true)

})

// New Blocks

onEvent('block.registry', event => {

  event.create('db_advanced_barrel').material('stone').hardness(1.0).displayName('Advanced Barrel').requiresTool(true)
  event.create('db_alloy_mixer').material('stone').hardness(1.0).displayName('Alloy Mixer').requiresTool(true)
  event.create('db_basic_barrel').material('stone').hardness(1.0).displayName('Basic Barrel').requiresTool(true)
  event.create('db_bedrock_infuser').material('stone').hardness(1.0).displayName('Bedrock Infuser').requiresTool(true)
  event.create('db_dragon_infuser').material('stone').hardness(1.0).displayName('Dragon Infuser').requiresTool(true)
  event.create('db_eroder').material('stone').hardness(1.0).displayName('Eroder').requiresTool(true)
  event.create('db_fragment_combiner').material('stone').hardness(1.0).displayName('Fragment Combiner').requiresTool(true)
  event.create('db_ore_extractor').material('stone').hardness(1.0).displayName('Ore Extractor').requiresTool(true)
  event.create('db_organic_producer').material('stone').hardness(1.0).displayName('organic Producer').requiresTool(true)
  event.create('db_soul_forge').material('stone').hardness(1.0).displayName('Soul Forger').requiresTool(true)
  event.create('db_water_generator').material('stone').hardness(1.0).displayName('Water Generator').requiresTool(true)

})

//New Fluids


onEvent('fluid.registry', event => {
  event.create('caveopolis:ore_forming_water').displayName('矿物质水').thickTexture(0x44DCFF).bucketColor(0x44DCFF)
  event.create('caveopolis:nuclear_waste_fluid').displayName('核废料').thickTexture(0x964B00).bucketColor(0x964B00)


})

/*

onEvent('fluid.registry', event => {
  // Add sulfuric acid fluid.

  event.create('sulfur_acid')
  .thinTexture(0xFFFF00)
  .bucketColor(0xFFFF00)
  .color(0xFFFF00)
  .displayName('Sulfuric Acid')
})

*/

//Disable Nether Portals

onForgeEvent('net.minecraftforge.event.world.BlockEvent$PortalSpawnEvent', event => {
  event.setCanceled(true)
})