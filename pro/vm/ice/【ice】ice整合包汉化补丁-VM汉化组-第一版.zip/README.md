# \*Ice\* 汉化补丁
CurseForge|Modrinth|Modpack Version|Status
:-|:-|:-|:-
[Modpack](https://www.curseforge.com/minecraft/modpacks/magic-ice-tech)|[Modpack]()|1.0.3|*Active*|
# 作者
查看贡献者列表以获得完整列表
# 鸣谢

# 仓库统计数据
  ![Alt]()

# 关于我们
  [![Website](https://shields.io/website?up_message=vmct-cn.top&url=http://vmct-cn.top&label=Website)](http://vmct-cn.top)
  [![Bilibili](https://shields.io/website?up_message=Space&url=https://space.bilibili.com/2085089798/&label=Bilibili)](https://space.bilibili.com/2085089798/)
  
<!--
  仓库统计数据等都需要自己填写，只是个模板而已，不会写那么细。
  仓库统计数据的表格来这里获取https://repobeats.axiom.co/ 然后将链接填写至空格当中
-->
