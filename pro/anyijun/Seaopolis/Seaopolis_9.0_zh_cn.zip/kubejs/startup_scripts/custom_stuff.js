// priority: 0

console.info('Hello, World! (You will only see this line once in console, during startup)')

// New Items
events.listen('item.registry', event => {

event.create('sea_bucks').displayName('海之印')
event.create('ender_ingot').displayName('冶炼末影锭')
event.create('dust').displayName('灰尘')
event.create('star').displayName('星星')
event.create('wood_gear').displayName('木齿轮')
event.create('wood_plate').displayName('木板')
event.create('cobalt_ore_chunk').displayName('钴矿石碎块')
event.create('cobalt_ore_piece').displayName('钴矿石碎片')
event.create('iron_golem').displayName('铁傀儡召唤器').maxStackSize(1)
event.create('water_bowl').food(food => {food.hunger(0).saturation(0.1).effect('minecraft:water_breathing', 500, 0, 1.0).eaten(e => {console.log(e.player + " ate " + e.item); e.server.runCommandSilent(`give ${e.player} minecraft:bowl`)})}).displayName('水碗').maxStackSize(8)
event.create('leafy_stew').food(food => {food.hunger(2).saturation(3).eaten(e => {console.log(e.player + " ate " + e.item); e.server.runCommandSilent(`give ${e.player} minecraft:bowl`)})}).displayName('绿叶炖菜').maxStackSize(8)
event.create('pumpkin_juice').food(food => {food.hunger(6).saturation(1).eaten(e => {console.log(e.player + " ate " + e.item); e.server.runCommandSilent(`give ${e.player} minecraft:glass_bottle`)})}).displayName('南瓜汁').maxStackSize(8)
event.create('melon_juice').food(food => {food.hunger(6).saturation(1).eaten(e => {console.log(e.player + " ate " + e.item); e.server.runCommandSilent(`give ${e.player} minecraft:glass_bottle`)})}).displayName('西瓜汁').maxStackSize(8)
event.create('seabuck_coffee').food(food => {food.hunger(2).saturation(2).effect('minecraft:speed', 100, 9, 1.0).eaten(e => {console.log(e.player + " ate " + e.item); e.server.runCommandSilent(`give ${e.player} minecraft:glass_bottle`)})}).displayName('海之印咖啡').maxStackSize(8)
event.create('cooked_apple').food(food => {food.hunger(6).saturation(1)}).displayName('烤苹果').maxStackSize(64)

})

// New Blocks

events.listen('block.registry', event => {

//event.create('blank_ore').material('rock').hardness(1.0).displayName('空白矿石').requiresTool(true)
event.create('compressed_red_sand').displayName('压缩红沙').material('sand').requiresTool(false).hardness(1.0)
event.create('overworld_matter').displayName('主世界物质').material('dirt').requiresTool(false).hardness(1.0)
event.create('compressed_overworld_matter').displayName('压缩主世界物质').material('dirt').requiresTool(false).hardness(1.5)
event.create('compressed_smooth_stone').displayName('压缩平滑石头').material('stone').requiresTool(true).hardness(1.5)
event.create('map').displayName('地图生成器').material('wood').requiresTool(false).hardness(1.0)
event.create('map1').displayName('地图生成器（海底神殿）').material('wood').requiresTool(false).hardness(2.0)
event.create('map2').displayName('地图生成器（要塞）').material('wood').requiresTool(false).hardness(2.0)
event.create('map3').displayName('地图生成器（诡异花园）').material('wood').requiresTool(false).hardness(2.0)
event.create('map4').displayName('地图生成器（利维坦）').material('wood').requiresTool(false).hardness(2.0)
event.create('map5').displayName('地图生成器（下界要塞）').material('wood').requiresTool(false).hardness(2.0)
event.create('map6').displayName('地图生成器（堡垒遗迹）').material('wood').requiresTool(false).hardness(2.0)
event.create('map7').displayName('地图生成器（末地城）').material('wood').requiresTool(false).hardness(2.0)
event.create('map8').displayName('地图生成器（起源之地）').material('wood').requiresTool(false).hardness(2.0)
event.create('compressed_prismarine').displayName('压缩海晶石').material('stone').requiresTool(true).hardness(1.5)
event.create('blank_ore').displayName('空白矿石').material('stone').requiresTool(true).hardness(2.0)
})

// New Fluids
events.listen('fluid.registry', event => {

event.create('organic_fluid').textureThick(0x86A774).displayName('有机水').bucketColor(0x86A774) 
event.create('molten_overworld_matter').textureThick(0x00FF21).displayName('熔融主世界物质').bucketColor(0x00FF21)
//event.create('weak_eroding_fluid').textureThick(0x392C4C).displayName('弱蚀水').bucketColor(0x392C4C)
//event.create('weak_enriching_fluid').textureThick(0xD79113).displayName('弱富集水').bucketColor(0xD79113)
//event.create('strong_enriching_fluid').textureThick(0x808080).displayName('强富集水').bucketColor(0x808080)
//event.create('nether_enriching_fluid').textureThick(0x580704).displayName('下界富集水').bucketColor(0x580704)
//event.create('end_enriching_fluid').textureThick(0xD9E0A4).displayName('末地富集水').bucketColor(0xD9E0A4)
//event.create('ore_fluid').textureThick(0x44DCFF).displayName('成矿水').bucketColor(0x44DCFF)
//event.create('creosote_fluid').textureThick(0x7F2300).displayName('强力杂酚油').bucketColor(0x7F2300)

})

onEvent("item.modification", event => {
    //Modification happens here
  
    event.modify("minecraft:saddle", item => {
      item.setMaxStackSize(64);
    })
  })