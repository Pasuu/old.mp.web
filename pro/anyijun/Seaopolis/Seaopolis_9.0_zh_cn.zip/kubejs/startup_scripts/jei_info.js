events.listen('jei.information', function (event) {

// Recipe JEI
    
event.add('minecraft:scute', '会从完全长大后的海龟身上掉落。也可杀死小海龟得到它们。但是为什么')
event.add('bhc:red_heart', '从友好生物身上掉落')
event.add('bhc:yellow_heart', '从敌对生物身上掉落')
event.add('bhc:green_heart', '从下界的敌对生物身上掉落')
event.add('bhc:blue_heart', '从末影龙和凋灵之类的Boss生物身上掉落')

})
    
// Tool Tip JEI
    
onEvent('item.tooltip', event => {
    
event.add('kubejs:iron_golem', [Text.of('召唤一个铁傀儡来帮你战斗！')])
event.add('industrialforegoing:block_breaker', [Text.of('如果放置在FTB区块的保护区内，就必须结盟').red()])
event.add('industrialforegoing:block_placer', [Text.of('如果放置在FTB区块的保护区内，就必须结盟').red()])
event.add('kubejs:cooked_apple', [Text.of('新鲜的烤苹果，好吃').red()])
event.add('bhc:red_heart', [Text.of('从友好生物身上掉落')])
event.add('bhc:yellow_heart', [Text.of('从敌对生物身上掉落')])
event.add('bhc:green_heart', [Text.of('从下界的敌对生物身上掉落')])
event.add('bhc:blue_heart', [Text.of('从末影龙和凋灵之类的Boss生物身上掉落')])
    
})
    
//Hide JEI Items
    
onEvent('jei.hide.items', event => {
    
event.hide('thermal:copper_ore')
event.hide('thermal:tin_ore')
event.hide('mekanism:dust_sulfur')
event.hide('industrialforegoing:tinydryrubber')
event.hide('libvulpes:plateiron')
event.hide('libvulpes:plategold')
event.hide('libvulpes:platecopper')
event.hide('libvulpes:platetin')
event.hide('mysticalagriculture:brass_seeds')
event.hide('mysticalagriculture:mithril_seeds')
event.hide('mysticalagriculture:tungsten_seeds')
event.hide('mysticalagriculture:chrome_seeds')
  
})
    
    