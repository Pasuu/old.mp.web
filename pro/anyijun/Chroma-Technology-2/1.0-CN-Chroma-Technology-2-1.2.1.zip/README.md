<!-- markdownlint-disable MD033 -->
# Chroma-Technology-2

[![Website](https://shields.io/website?up_message=anyijun.com&url=http://anyijun.com&label=Website)](http://anyijun.com)
[![License](https://img.shields.io/badge/License-CC%20BY--NC--ND%204.0-blue)](https://github.com/ShaBaiTianCN/Chroma-Technology-2/blob/master/LICENSE)
[![Downloads](https://shields.io/github/downloads/ShaBaiTianCN/Chroma-Technology-2/total?label=Downloads)](https://github.com/ShaBaiTianCN/Chroma-Technology-2/releases)
[![Release](https://shields.io/github/v/release/ShaBaiTianCN/Chroma-Technology-2?display_name=tag&include_prereleases&label=Release)](https://github.com/ShaBaiTianCN/Chroma-Technology-2/releases/latest)

## 仓库说明

这里是 Chroma-Technology-2 整合包简体中文汉化仓库。

![汉化补丁食用说明](汉化补丁食用说明.jpg)

## 许可

<a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/4.0/"><img alt="知识共享许可协议" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-nd/4.0/88x31.png" /></a><br />本作品采用<a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/4.0/">知识共享署名-非商业性使用-禁止演绎 4.0 国际许可协议</a>进行许可。
