//JEI Recipes
onEvent('jei.information', event => {
	event.add('kubejs:netherrack_dust', ['基础魔杖或更好的魔杖可以把下界岩转成下界岩粉'])
	event.add('minecraft:warped_fungus', ['基础魔杖或更好的魔杖可以把诡异疣块转成诡异菌'])
	event.add('minecraft:crimson_fungus', ['基础魔杖或更好的魔杖可以把下界疣块转成绯红菌'])
	event.add('minecraft:soul_campfire', ['基础魔杖或更好的魔杖可以点燃灵魂沙，紧接着你的魔杖可以把灵魂火转成灵魂营火。这会对你造成3颗心的伤害！'])
	event.add('minecraft:bone', ['基础魔杖或更好的魔杖可以把骨块转成骨头'])
	event.add('tconstruct:crafting_station', ['基础魔杖或更好的魔杖可以把工作台转成工作站'])
	event.add('minecraft:blackstone', ['高级魔杖或更好的魔杖可以把灵魂砂岩转成黑石'])
	event.add('minecraft:dirt', ['高级魔杖或更好的魔杖可以把灵浆粘性泥土转成泥土'])
	event.add('minecraft:flint', ['高级魔杖或更好的魔杖可以把沙砾转成燧石'])
	event.add('minecraft:magma_cream', ['高级魔杖或更好的魔杖可以把岩浆块转成岩浆膏'])
	event.add('minecraft:stone', ['石英钴魔杖或更好的魔杖可以把焦黑石头转成石头'])
	event.add('minecraft:bucket', ['石英钴魔杖或更好的魔杖可以把漏斗转成桶'])
	event.add('minecraft:white_wool', ['石英钴魔杖或更好的魔杖可以把石英块转成羊毛'])
	event.add('psi:psigem', ['对烈焰人用钻石进行交易会给你一个Psi宝石'])
	event.add('psi:psimetal', ['对烈焰人用金锭进行交易会给你一个Psi金属锭'])
	event.add('psi:programmer', ['对烈焰人用血之祭坛进行交易会给你一个术式编写台'])
	event.add('psi:cad_assembler', ['对烈焰人用工作站进行交易会给你一个CAD装配器'])

});

onEvent('item.tooltip', event => {
	event.add('kubejs:battleaxe', [Text.of('可以用斧子破坏的方块几乎立即破坏。也能造成不戳的伤害')])
	event.add('kubejs:pink_sword', [Text.of('高伤害的剑')])
	event.add('kubejs:stick', [Text.of('“你也可以用棍子做你想做的事”Paul')])
	event.add('kubejs:instant_health_stew', [Text.of('全面回血')])
	event.add('kubejs:regeneration_stew', [Text.of('短时间内提供再生III').colour(blue)])

	Item.of('minecraft:golden_helmet', {RepairCost:1,AS_Amulet_Holder:[1109753370,2103592887,-2023103023,62750564],Damage:0,Enchantments:[{lvl:1,id:"astralsorcery:night_vision"}]})


})
//JEI Hide
onEvent(['jei.hide.items', 'rei.hide.items'], event => {

function tool(type){
    event.hide('/minecraft:' + type + '_sword/')
    event.hide('/minecraft:' + type + '_pickaxe/')
    event.hide('/minecraft:' + type + '_axe/')
    event.hide('/minecraft:' + type + '_hoe/')
    event.hide('/minecraft:' + type + '_shovel/')}
tool('wooden')
tool('stone')
tool('golden')
tool('diamond')
tool('iron')
tool('netherite')
event.hide('immersive_portals:portal_helper')
event.hide('skyblockbuilder:structure_saver')
event.hide('custommachinery:machine_creator_item')
event.hide('custommachinery:box_creator_item')
event.hide(['occultism:copper_ore', 'occultism:copper_nugget', 'occultism:copper_block', 'occultism:copper_ingot'])

})

//JEI Add
onEvent('jei.add.items', e => {
	e.add([
  	'minecraft:dragon_egg',
	Item.of('minecraft:leather_chestplate', {AS_Amulet_Holder:[1109753370,2103592887,-2023103023,62750564],Damage:0,AttributeModifiers:[{Slot:"chest",AttributeName:"generic.max_health",UUID:[-121530,35539,16285,-71078],Amount:-18,Name:"generic.max_health"},{Slot:"chest",AttributeName:"generic.movement_speed",UUID:[-121530,35639,16285,-71278],Amount:0.1,Name:"generic.movement_speed"}],display:{Lore:[[{"text":"穿戴时会降低最大生命值，穿戴时会提供夜视和提高移动速度","italic":false}]],Name:"[{\"text\":\"符文外套\",\"italic\":false}]"},Enchantments:[{lvl:1,id:"protection"}]}),
	Item.of('versatileportals:existing_world_control', {RepairCost:0,WorldID:"infernopolis:ghast_lands",display:{Name:"{\"text\":\"恶魂之地宝石\"}"},Color:11943875}),
	Item.of('versatileportals:existing_world_control', {RepairCost:0,WorldID:"infernopolis:nether_islands",display:{Name:"{\"text\":\"下界群岛宝石\"}"},Color:13772502}),
	Item.of('versatileportals:existing_world_control', {RepairCost:0,WorldID:"infernopolis:seaopolis",display:{Name:"{\"text\":\"海之城宝石\"}"},Color:7308118}),
	Item.of('versatileportals:existing_world_control', {WorldID:"infernopolis:the_missing_world",display:{Name:"{\"text\":\"消失世界宝石\"}"},Color:9531362}),
	Item.of('versatileportals:existing_world_control', {display:{Name:"{\"text\":\"末地宝石\"}"},Color:13024191,WorldID:"minecraft:the_end"}),
	Item.of('versatileportals:existing_world_control', {RepairCost:0,WorldID:"minecraft:overworld",display:{Name:"{\"text\":\"主世界？\"}"},Color:3669742})
    ]);
});
