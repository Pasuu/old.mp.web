//New Items

//Tool Tiers
events.listen('item.registry.tool_tiers', event => {
event.add("battleaxe", (tier) => {   
    tier.speed = 100,
    tier.level = 3,
    tier.attackDamageBonus = 7
})
event.add("pinksword", (tier) => {   
    tier.speed = 1,
    tier.level = 3,
    tier.attackDamageBonus = 13
})
event.add("sign", (tier) => {   
    tier.speed = 1,
    tier.level = 1,
    tier.attackDamageBonus = -2,
    tier.repairIngredient = 'minecraft:planks'
})

})

//Basic Items

events.listen('item.registry', event => {
event.create('basic_wand').displayName('基础魔杖').maxStackSize(1)
event.create('advanced_wand').displayName('高级魔杖').maxStackSize(1)
//event.create('hell_bucks').displayName('地狱印')
event.create('netherrack_dust').displayName('下界岩粉')
event.create('soul_dust').displayName('灵魂尘')
event.create('quartz_cobalt_wand').displayName('石英钴魔杖').maxStackSize(1)
event.create('aqua_ball').displayName('水球')
event.create('spawner_shard').displayName('刷怪笼碎片').maxStackSize(1)
event.create('activated_spawner_shard').displayName('激活的刷怪笼碎片').glow(true).maxStackSize(1)
event.create('summoner_wand').displayName('召唤师魔杖').glow(true).maxStackSize(1)
event.create('blood_diamond').displayName('血钻')
event.create('magical_dust').displayName('魔力尘')
event.create('sphere_generator').displayName('球体生成器')

//Custom Foods (.effect('custom effect', duration, level))
event.create('instant_health_stew').food(food => {food.hunger(6).saturation(0.5).effect('minecraft:instant_health', 2, 4, 1.0).eaten(e => {console.log(e.player + " ate " + e.item); e.server.runCommandSilent(`give ${e.player} minecraft:bowl`)})}).displayName('瞬间治疗炖菜').maxStackSize(16).glow(true)
event.create('regeneration_stew').food(food => {food.hunger(6).saturation(0.5).effect('minecraft:regeneration', 200, 2, 1.0).eaten(e => {console.log(e.player + " ate " + e.item); e.server.runCommandSilent(`give ${e.player} minecraft:bowl`)})}).displayName('再生炖菜').maxStackSize(16).glow(true)
event.create('apple').food(food => {food.hunger(4).saturation(0.4).effect('minecraft:poison', 60, 1, 1.0)}).displayName('"苹果"').maxStackSize(16)

//Surpoters Items

event.create('battleaxe').displayName("Moody的战斧").type('axe').unstackable().tier('battleaxe').maxDamage(500); //
event.create('pink_sword').displayName("§dAkeihra的粉色华丽剑").type('sword').unstackable().tier('pinksword').maxDamage(250);
event.create('purple_sword').displayName("§5紫色善良紫剑").type('sword').unstackable().tier('pinksword').maxDamage(250);
event.create('stick').displayName("闪光棒").glow(true);
event.create('sign').displayName("§4至尊标志").type('sword').unstackable().tier('sign').maxDamage(64).attackSpeed(3);

//const ur_item = event.create('sign').displayName("至尊标志").type('sword').unstackable().tier('sign').maxDamage(64);
//ur_item.attackSpeedBaseline = 5;


//event.create('patreon:battleaxe').displayName('Moody的战斧').type('axe').maxDamage(500).attackDamage(20).attackSpeed(14).miningSpeed(1000).tooltip('我是自定义物品，你好').unstackable()
//vent.create('seabuck_coffee').food(food => {food.hunger(2).saturation(2).effect('minecraft:speed', 100, 9, 1.0).eaten(e => {console.log(e.player + " ate " + e.item); e.server.runCommandSilent(`give ${e.player} minecraft:glass_bottle`)})}).displayName('海之印咖啡').maxStackSize(8)
//event.create('cooked_apple').food(food => {food.hunger(6).saturation(1)}).displayName('烤苹果').maxStackSize(64)

})

//New Blocks

events.listen('block.registry', event => {

event.create('unpowered_starmetal_ore').displayName('未充能的星辉矿石').material('rock').hardness(1.0).requiresTool(true)
event.create('aqua_bricks').displayName('水砖块').material('rock').hardness(1.0).requiresTool(true)
//event.create('infuser').displayName('注射器').material('rock').hardness(1.2).requiresTool(true)

})

// New Fluids
events.listen('fluid.registry', event => {
event.create('starmetal').textureThick(0xE4DFD5).displayName('熔融星辉').bucketColor(0x08083A).textureThick(0x08083A)
event.create('organic_fluid').textureThick(0x86A774).displayName('有机水').bucketColor(0x86A774) 
//event.create('starmetal').textureThick(0xE4DFD5).displayName('熔融星辉').bucketColor(0x08083A).textureStill('kubejs:fluid/starmetal').textureFlowing('kubejs:fluid/starmetal_flowing')
//event.create('weak_enriching_fluid').textureThick(0xD79113).displayName('弱富集水').bucketColor(0xD79113)
//event.create('strong_enriching_fluid').textureThick(0x808080).displayName('强富集水').bucketColor(0x808080)
//event.create('nether_enriching_fluid').textureThick(0x580704).displayName('下界富集水').bucketColor(0x580704)
//event.create('end_enriching_fluid').textureThick(0xD9E0A4).displayName('末地富集水').bucketColor(0xD9E0A4)
//event.create('ore_fluid').textureThick(0x44DCFF).displayName('成矿水').bucketColor(0x44DCFF)
//event.create('creosote_fluid').textureThick(0x7F2300).displayName('Strong Creosote Oil').bucketColor(0x7F2300)

})