//Blaze Trading

//Blaze (PSI Gem)
onEvent('item.entity_interact', event => {
    if (event.hand == MAIN_HAND)
    if (event.item.id == 'minecraft:diamond')
    if (event.target.type == 'minecraft:blaze'){
    if (!event.player.isCreativeMode()) {event.item.setCount(event.item.getCount() - 1)}
      event.server.schedule(5, event.server, function (callback) {                                 
      callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run summon item ${event.target.x} ${event.target.y+0.5} ${event.target.z} {Item:{id:'psi:psigem',Count:1b}}`);  
      callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run tellraw @p {"text":"谢谢你的钻石给你个Psi宝石","color":"green"}`);  
   })}})
  //Blaze Trading (PSI Metal)
  onEvent('item.entity_interact', event => {
    if (event.hand == MAIN_HAND)
    if (event.item.id == 'minecraft:gold_ingot')
    if (event.target.type == 'minecraft:blaze'){
    if (!event.player.isCreativeMode()) {event.item.setCount(event.item.getCount() - 1)}
      event.server.schedule(5, event.server, function (callback) {                                 
      callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run summon item ${event.target.x} ${event.target.y+0.5} ${event.target.z} {Item:{id:'psi:psimetal',Count:1b}}`);  
      callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run tellraw @p {"text":"谢谢你的金锭给你个Psi金属锭","color":"green"}`);  
   })}})
  //Blaze Trading (Rod Constructor)
  onEvent('item.entity_interact', event => {
    if (event.hand == MAIN_HAND)
    if (event.item.id == 'tconstruct:crafting_station')
    if (event.target.type == 'minecraft:blaze'){
    if (!event.player.isCreativeMode()) {event.item.setCount(event.item.getCount() - 1)}
      event.server.schedule(5, event.server, function (callback) {                                 
      callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run summon item ${event.target.x} ${event.target.y+0.5} ${event.target.z} {Item:{id:'psi:cad_assembler',Count:1b}}`);  
      callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run tellraw @p {"text":"谢谢你的工作站给你个CAD装配器","color":"green"}`);  
   })}})
  //Blaze Trading (Rod Programer)
  onEvent('item.entity_interact', event => {
    if (event.hand == MAIN_HAND)
    if (event.item.id == 'bloodmagic:altar')
    if (event.target.type == 'minecraft:blaze'){
    if (!event.player.isCreativeMode()) {event.item.setCount(event.item.getCount() - 1)}
      event.server.schedule(5, event.server, function (callback) {                                 
      callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run summon item ${event.target.x} ${event.target.y+0.5} ${event.target.z} {Item:{id: 'psi:programmer',Count:1b}}`);  
      callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run tellraw @p {"text":"谢谢你的血之祭坛给你个术式编写台","color":"green"}`);  
   })}})
  //Blaze Trading (Empty Handed)
  // onEvent('item.entity_interact', event => {
  //  if (event.hand == MAIN_HAND)
  //  if (event.item.id == 'minecraft:air')
  //  if (event.target.type == 'minecraft:blaze'){
  //    event.server.schedule(5, event.server, function (callback) {                                 
  //   callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run tellraw @p {"text":"你什么都不给我！","color":"dark_red"}`);
  // })}})
  //Blaze Trading (Wrong Item)
   onEvent('item.entity_interact', event => {
    if (event.hand == MAIN_HAND)
    if (event.item.id != 'minecraft:diamond')
    if (event.item.id != 'minecraft:air')
    if (event.item.id != 'minecraft:gold_ingot')
    if (event.item.id != 'bloodmagic:altar')
    if (event.item.id != 'tconstruct:crafting_station')
    if (event.target.type == 'minecraft:blaze'){
      event.server.schedule(5, event.server, function (callback) {                                 
      callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run tellraw @p {"text":"我不需要这个！","color":"dark_red"}`);
   })}})

   //TEST
