//Block Loot Tables

onEvent('block.loot_tables', event => {
event.addSimpleBlock('#forge:ores')
event.addSimpleBlock('minecraft:gravel')
event.addSimpleBlock('minecraft:spawner', 'kubejs:spawner_shard') 
// To drop a different item//event.addSimpleBlock(/minecraft:.*_ore/, 'minecraft:red_sand') // To drop a different item
})

//No XP from ores

onEvent("block.break", e => {
  if(!e.server) return;
  if(e.block.hasTag("forge:ores")) {
    e.setXp(0);
  }
})
 
//Tag Death

onEvent('entity.death', event => {
  if (event.entity.type == 'minecraft:player'){

    event.server.schedule(1000, event.server, function (callback) { 
    callback.server.runCommandSilent(`tag @e add death`);
    })
    event.server.schedule(30000, event.server, function (callback) {                                  
      callback.server.runCommandSilent(`tag @e remove death`);
   })
  }
})

//Death Checker

onEvent('item.right_click', event => {
  if (event.item.hasTag('infernopolis:banned_after_death'))
  if (event.player.getTags().contains('death')){
  event.server.schedule(5, event.server, function (callback) {
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run tellraw @e {"text":"你太虚弱了，不能抽血！","color":"dark_red"}`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run attribute @e minecraft:generic.max_health base set 1`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run effect @e minecraft:poison 1 1`);
    callback.server.runCommandSilent(`tag @e remove death`);
  })
  event.server.schedule(30000, event.server, function (callback) {
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run tellraw @e {"text":"你开始恢复体力","color":"green"}`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run attribute @e minecraft:generic.max_health base set 20`);
    })
  }
})

//Sphere Generator (create)

onEvent('item.right_click', event => {
  if (event.item.id == 'kubejs:sphere_generator'){
    event.server.schedule(5, event.server, function (callback) {
 //     callback.server.runCommandSilent(`execute as ${event.player.name} in infernopolis:seaopolis run setblock ${event.player.x} 54 ${event.player.z} minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 1b, powered: 0b, seed: 0L, author: "benbenlaw", rotation: "NONE", posX: -7, mode: "LOAD", posY: 0, sizeX: 15, posZ: -7, integrity: 1.0f, showair: 0b, x: 6, name: "infernopolis:seaopolis", y: 60, z: -6, id: "minecraft:structure_block", sizeY: 15, sizeZ: 15, showboundingbox: 1b}`); 
//      callback.server.runCommandSilent(`execute as ${event.player.name} in infernopolis:seaopolis run setblock ${event.player.x} 75 ${event.player.z} minecraft:redstone_block`); 
      callback.server.runCommandSilent(`say Coming Soon`);
    })
  }
})

onEvent('item.right_click', event => {
  if (event.item.id == 'calemiutils:coin_penny')event.cancel()
  })

//New Gamerule

onEvent('player.logged_in', event =>{
  event.server.schedule(5, event.server, function (callback) {     
  callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run gamerule doTraderSpawning false`);
  callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run tellraw @p {"text":"欢迎回到地狱城","color":"red"}`);  
  })})


//onEvent('item.toss', event => {
  //if (event.item.id == 'minecraft:leather_chestplate'){
 //     event.server.schedule(5, event.server, function (callback) {
//callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run say hello`); 
//
 //   })
//  }
//})
// callback.server.runCommandSilent(`execute in infernopolis:seaopolis as ${event.player.name} run setblock ${event.player.x} ${event.player.y} ${event.player.z} minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 1b, powered: 0b, seed: 0L, author: "benbenlaw", rotation: "NONE", posX: -7, mode: "LOAD", posY: 0, sizeX: 15, posZ: -7, integrity: 1.0f, showair: 0b, x: 6, name: "infernopolis:seaopolis", y: 60, z: -6, id: "minecraft:structure_block", sizeY: 15, sizeZ: 15, showboundingbox: 1b}`); 


//      event.setblock.id == Item.of('minecraft:structure_block', {BlockEntityTag:{metadata:"",mirror:"NONE",ignoreEntities:1,powered:0,seed:0,author:"benbenlaw",rotation:"NONE",posX:-7,mode:"LOAD",posY:-7,sizeX:15,posZ:-7,integrity:1.0,showair:0,name:"infernopolis:seaopolis",id:"minecraft:structure_block",sizeY:15,sizeZ:15,showboundingbox:1},display:{Lore:["(+NBT)"]}}




// /execute in infernopolis:seaopolis as @p run setblock ~ 54 ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 1b, powered: 0b, seed: 0L, author: "benbenlaw", rotation: "NONE", posX: -7, mode: "LOAD", posY: 0, sizeX: 15, posZ: -7, integrity: 1.0f, showair: 0b, x: 6, name: "infernopolis:seaopolis", y: 60, z: -6, id: "minecraft:structure_block", sizeY: 15, sizeZ: 15, showboundingbox: 1b}
// /setblock ~1 54 ~ minecraft:redstone_block