//Summoner Wand (Pig)
onEvent('block.right_click', event => {
    if (event.hand == MAIN_HAND)
    if (event.item.hasTag('infernopolis:summoner_wand'))
    if (event.block.id == 'tconstruct:pig_iron_block'){
      event.server.schedule(5, event.server, function (callback) {                                 
      callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run setblock ${event.block.x} ${event.block.y} ${event.block.z} minecraft:air`);
      callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run summon minecraft:pig ${event.block.x} ${event.block.y} ${event.block.z}`);
      callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle minecraft:dust 0.858 0.6 0.584 2 ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0.4 0.4 0.4 10 100`);
  })}})
  //Summoner Wand (Cow)
  onEvent('block.right_click', event => {
    if (event.hand == MAIN_HAND)
    if (event.item.hasTag('infernopolis:summoner_wand'))
    if (event.block.id == 'quark:bonded_leather'){
      event.server.schedule(5, event.server, function (callback) {                                 
      callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run setblock ${event.block.x} ${event.block.y} ${event.block.z} minecraft:air`);
      callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run summon minecraft:cow ${event.block.x} ${event.block.y} ${event.block.z}`);
      callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle minecraft:dust 0.674 0.290 0.152 2 ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0.4 0.4 0.4 10 100`);
  })}})
  //Summoner Wand (Cow)
  onEvent('block.right_click', event => {
    if (event.hand == MAIN_HAND)
    if (event.item.hasTag('infernopolis:summoner_wand'))
    if (event.block.id == 'tconstruct:blood_slime'){
      event.server.schedule(5, event.server, function (callback) {                                 
      callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run setblock ${event.block.x} ${event.block.y} ${event.block.z} minecraft:air`);
      callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run summon minecraft:villager ${event.block.x} ${event.block.y} ${event.block.z}`);
      callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle minecraft:dust 0.674 0.290 0.152 2 ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0.4 0.4 0.4 10 100`);
  })}})
  //SUmmoner Wand (Friendly Blaze)
  onEvent('block.right_click', event => {
    if (event.hand == MAIN_HAND)
    if (event.item.hasTag('infernopolis:summoner_wand'))
    if (event.block.id == 'quark:blaze_lantern'){
      event.server.schedule(5, event.server, function (callback) {                                 
      callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run setblock ${event.block.x} ${event.block.y} ${event.block.z} minecraft:air`);
      callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run summon minecraft:blaze ${event.block.x} ${event.block.y} ${event.block.z} {NoAI:1,CustomNameVisible:1b,CustomName:'{"text":"烈焰商人"}'}`);
      callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle minecraft:dust 0.674 0.290 0.152 2 ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0.4 0.4 0.4 10 100`);
  })}})