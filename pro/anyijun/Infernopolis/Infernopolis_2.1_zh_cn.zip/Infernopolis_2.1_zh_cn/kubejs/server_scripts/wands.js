//Basic Wand

//Basic Wand (Drop Netherrack)
onEvent('block.right_click', event => {
  if (event.hand == MAIN_HAND)
  if (event.item.hasTag('infernopolis:basic_wand'))
  if (event.block.hasTag('forge:netherrack')){
    event.server.schedule(5, event.server, function (callback) {
    event.player.addItemCooldown(event.player.getHeldItem(MAIN_HAND), 2)   
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run summon item ${event.block.x} ${event.block.y+0.5} ${event.block.z} {Item:{id:"kubejs:netherrack_dust",Count:1b}}`);                                       
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run setblock ${event.block.x} ${event.block.y} ${event.block.z} minecraft:air`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle block ${event.block.id} ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0 0 0 0.2 30`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle crimson_spore ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0 0 0 0.2 30`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle dragon_breath ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0 0 0 0.2 30`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle flame ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0 0 0 0.2 30`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run playsound minecraft:block.wood.break block @s ${event.block.x} ${event.block.y+0.5} ${event.block.z}`);
})}})

//Basic Wand (Drop Warped Fungas)
onEvent('block.right_click', event => {
  if (event.hand == MAIN_HAND)
  if (event.item.hasTag('infernopolis:basic_wand'))
  if (event.block.id == 'minecraft:warped_wart_block'){
    event.server.schedule(5, event.server, function (callback) {   
    event.player.addItemCooldown(event.player.getHeldItem(MAIN_HAND), 2)                                 
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run setblock ${event.block.x} ${event.block.y} ${event.block.z} minecraft:air`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run summon item ${event.block.x} ${event.block.y+0.5} ${event.block.z} {Item:{id:'minecraft:warped_fungus',Count:1b}}`);  
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run playsound minecraft:block.note_block.chime block @s ${event.block.x} ${event.block.y} ${event.block.z} 2 2`);   
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle minecraft:dust 0.086 0.490 0.517 2 ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0.2 0.2 0.2 10 100`);
})}})
//Basic Wand (Drop Crimson Fungas)
onEvent('block.right_click', event => {
  if (event.hand == MAIN_HAND)
  if (event.item.hasTag('infernopolis:basic_wand'))
  if (event.block.id == 'minecraft:nether_wart_block'){
    event.server.schedule(5, event.server, function (callback) {   
    event.player.addItemCooldown(event.player.getHeldItem(MAIN_HAND), 2)                                
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run setblock ${event.block.x} ${event.block.y} ${event.block.z} minecraft:air`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run summon item ${event.block.x} ${event.block.y+0.5} ${event.block.z} {Item:{id:'minecraft:crimson_fungus',Count:1b}}`);  
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run playsound minecraft:block.note_block.chime block @s ${event.block.x} ${event.block.y} ${event.block.z} 2 2`);   
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle minecraft:dust 0.764 0.2 0.219 2 ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0.2 0.2 0.2 10 100`);
})}})
//Basic Wand (Place Fire Soul Sand)
onEvent('block.right_click', event => {
  if (event.hand == MAIN_HAND)
  if (event.item.hasTag('infernopolis:basic_wand'))
  if (event.block.id == 'minecraft:soul_sand'){
    event.server.schedule(5, event.server, function (callback) {
      event.player.addItemCooldown(event.player.getHeldItem(MAIN_HAND), 10)                                  
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run setblock ${event.block.x} ${event.block.y+1} ${event.block.z} minecraft:soul_fire`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run playsound minecraft:item.flintandsteel.use block @s ${event.block.x} ${event.block.y} ${event.block.z} 2 2`);   
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle minecraft:dust 0.086 0.490 0.517 2 ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0.4 0.4 0.4 10 100`);
})}})
//Basic Wand (Place Campfire)
onEvent('block.right_click', event => {
  if (event.hand == MAIN_HAND)
  if (event.item.hasTag('infernopolis:basic_wand'))
  if (event.block.id == 'minecraft:soul_fire'){
    event.server.schedule(5, event.server, function (callback) {                         
    event.player.addItemCooldown(event.player.getHeldItem(MAIN_HAND), 10)                                
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run setblock ${event.block.x} ${event.block.y} ${event.block.z} minecraft:soul_campfire`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run playsound minecraft:item.flintandsteel.use block @s ${event.block.x} ${event.block.y} ${event.block.z} 2 2`);   
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle minecraft:dust 0.086 0.490 0.517 2 ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0.4 0.4 0.4 10 100`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run effect give @s minecraft:instant_damage 1 0`);
})}})
//Basic Wand (Drop Bones)
onEvent('block.right_click', event => {
  if (event.hand == MAIN_HAND)
  if (event.item.hasTag('infernopolis:basic_wand'))
  if (event.block.id == 'minecraft:bone_block'){
    event.server.schedule(5, event.server, function (callback) { 
    event.player.addItemCooldown(event.player.getHeldItem(MAIN_HAND), 2)                                     
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run setblock ${event.block.x} ${event.block.y} ${event.block.z} minecraft:air`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run summon item ${event.block.x} ${event.block.y+0.5} ${event.block.z} {Item:{id:'minecraft:bone',Count:2b}}`);  
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run playsound minecraft:block.note_block.chime block @s ${event.block.x} ${event.block.y} ${event.block.z} 2 2`);   
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle minecraft:dust 0.988 0.988 0.980 2 ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0.2 0.2 0.2 10 100`);
})}})
//Basic Wand (Place Crafting Station)
onEvent('block.right_click', event => {
  if (event.hand == MAIN_HAND)
  if (event.item.hasTag('infernopolis:basic_wand'))
  if (event.block.id == 'minecraft:crafting_table'){
    event.server.schedule(5, event.server, function (callback) {   
    event.player.addItemCooldown(event.player.getHeldItem(MAIN_HAND), 2)                                 
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run setblock ${event.block.x} ${event.block.y} ${event.block.z} tconstruct:crafting_station`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run playsound minecraft:block.note_block.chime block @s ${event.block.x} ${event.block.y} ${event.block.z} 2 2`);   
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle minecraft:dust 0.466 0.380 0.227 2 ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0.4 0.4 0.4 10 100`);
})}})



//Advanced Wand

//Adv (Drop Blackstone)
onEvent('block.right_click', event => {
  if (event.hand == MAIN_HAND)
  if (event.item.hasTag('infernopolis:advanced_wand'))
  if (event.block.id == 'quark:soul_sandstone'){
    event.server.schedule(5, event.server, function (callback) { 
    event.player.addItemCooldown(event.player.getHeldItem(MAIN_HAND), 2)                                   
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run setblock ${event.block.x} ${event.block.y} ${event.block.z} minecraft:air`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run summon item ${event.block.x} ${event.block.y+0.5} ${event.block.z} {Item:{id:'minecraft:blackstone',Count:1b}}`);  
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run playsound minecraft:block.note_block.chime block @s ${event.block.x} ${event.block.y} ${event.block.z} 2 2`);   
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle minecraft:dust 0.074 0.066 0.082 2 ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0.2 0.2 0.2 10 100`);
})}})
//Adv (Place Dirt)
onEvent('block.right_click', event => {
  if (event.hand == MAIN_HAND)
  if (event.item.hasTag('infernopolis:advanced_wand'))
  if (event.block.id == 'tconstruct:ichor_slime_dirt'){
    event.server.schedule(5, event.server, function (callback) {    
    event.player.addItemCooldown(event.player.getHeldItem(MAIN_HAND), 2)                                
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run setblock ${event.block.x} ${event.block.y} ${event.block.z} minecraft:dirt`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run playsound minecraft:block.note_block.chime block @s ${event.block.x} ${event.block.y} ${event.block.z} 2 2`);   
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle minecraft:dust 0.658 0.474 0.329 2 ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0.4 0.4 0.4 10 100`);
})}})
//Adv (Drop Ores)
onEvent('block.right_click', event => {
  if (event.hand == MAIN_HAND)
  if (event.item.hasTag('infernopolis:advanced_wand'))
  if (event.block.hasTag('forge:ores')){
    event.server.schedule(5, event.server, function (callback) {
    event.player.addItemCooldown(event.player.getHeldItem(MAIN_HAND), 2)   
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run summon item ${event.block.x} ${event.block.y+0.5} ${event.block.z} {Item:{id:"${event.block.id}",Count:1b}}`);                                       
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run setblock ${event.block.x} ${event.block.y} ${event.block.z} minecraft:air`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle block ${event.block.id} ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0 0 0 0.2 30`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle crimson_spore ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0 0 0 0.2 30`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle dragon_breath ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0 0 0 0.2 30`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle flame ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0 0 0 0.2 30`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run playsound minecraft:block.stone.break block @s ${event.block.x} ${event.block.y+0.5} ${event.block.z}`);
})}})
//Adv (Drop Flint)
onEvent('block.right_click', event => {
  if (event.hand == MAIN_HAND)
  if (event.item.hasTag('infernopolis:advanced_wand'))
  if (event.block.id == 'minecraft:gravel'){
    event.server.schedule(5, event.server, function (callback) {     
    event.player.addItemCooldown(event.player.getHeldItem(MAIN_HAND), 2)                               
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run setblock ${event.block.x} ${event.block.y} ${event.block.z} minecraft:air`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run summon item ${event.block.x} ${event.block.y+0.5} ${event.block.z} {Item:{id:'minecraft:flint',Count:1b}}`);  
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run playsound minecraft:block.note_block.chime block @s ${event.block.x} ${event.block.y} ${event.block.z} 2 2`);   
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle minecraft:dust 0.074 0.066 0.082 2 ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0.2 0.2 0.2 10 100`);
})}})
//Adv (Drop Magma Cream)
onEvent('block.right_click', event => {
  if (event.hand == MAIN_HAND)
  if (event.item.hasTag('infernopolis:advanced_wand'))
  if (event.block.id == 'minecraft:magma_block'){
    event.server.schedule(5, event.server, function (callback) { 
    event.player.addItemCooldown(event.player.getHeldItem(MAIN_HAND), 2)                                   
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run setblock ${event.block.x} ${event.block.y} ${event.block.z} minecraft:air`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run summon item ${event.block.x} ${event.block.y+0.5} ${event.block.z} {Item:{id:'minecraft:magma_cream',Count:1b}}`);  
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run playsound minecraft:block.note_block.chime block @s ${event.block.x} ${event.block.y} ${event.block.z} 2 2`);   
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle minecraft:dust 0.635 0.768 0.286 2 ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0.2 0.2 0.2 10 100`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle minecraft:dust 0.698 0.094 0.223 2 ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0.2 0.2 0.2 10 100`);
})}})



//Cobalt Quartz Wand

//Cob (Place Stone)
onEvent('block.right_click', event => {
  if (event.hand == MAIN_HAND)
  if (event.item.hasTag('infernopolis:quartz_cobalt_wand'))
  if (event.block.id == 'tconstruct:seared_stone'){
    event.server.schedule(5, event.server, function (callback) {                                 
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run setblock ${event.block.x} ${event.block.y} ${event.block.z} minecraft:stone`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run playsound minecraft:block.note_block.chime block @s ${event.block.x} ${event.block.y} ${event.block.z} 2 2`);   
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle minecraft:dust 0.380 0.380 0.380 2 ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0.4 0.4 0.4 10 100`);
})}})
//Cob (Place Wool)
onEvent('block.right_click', event => {
  if (event.hand == MAIN_HAND)
  if (event.item.hasTag('infernopolis:quartz_cobalt_wand'))
  if (event.block.id == 'minecraft:quartz_block'){
    event.server.schedule(5, event.server, function (callback) {                                 
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run setblock ${event.block.x} ${event.block.y} ${event.block.z} minecraft:white_wool`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run playsound minecraft:block.note_block.chime block @s ${event.block.x} ${event.block.y} ${event.block.z} 2 2`);   
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle minecraft:dust 1 1 1 2 ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0.4 0.4 0.4 10 100`);
})}})
//Cob (Drop Bucket)
onEvent('block.right_click', event => {
if (event.hand == MAIN_HAND)
if (event.item.hasTag('infernopolis:quartz_cobalt_wand'))
if (event.block.id == 'minecraft:hopper'){
  event.server.schedule(5, event.server, function (callback) {                                 
  callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run setblock ${event.block.x} ${event.block.y} ${event.block.z} minecraft:air`);
  callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run summon item ${event.block.x} ${event.block.y+0.5} ${event.block.z} {Item:{id:'minecraft:bucket',Count:1b}}`);  
  callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run playsound minecraft:block.note_block.chime block @s ${event.block.x} ${event.block.y} ${event.block.z} 2 2`);   
  callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle minecraft:dust 0.443 0.443 0.443 2 ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0.2 0.2 0.2 10 100`);
})}})



//Misc World

//Breaking (Soul Campfire)
onEvent('block.break', event => {
  if (event.block.id == 'minecraft:soul_campfire'){
    event.server.schedule(5, event.server, function (callback) {                                 
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run setblock ${event.block.x} ${event.block.y} ${event.block.z} minecraft:soul_fire`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run kill @e[type=minecraft:item,nbt={Item:{id:"minecraft:soul_soil"}}]`);
    callback.server.runCommandSilent(`execute as ${event.player.name} in ${event.player.world.dimension} run particle minecraft:dust 0.086 0.490 0.517 2 ${event.block.x} ${event.block.y+0.5} ${event.block.z} 0.4 0.4 0.4 10 100`);
})}})

 //data merge entity @e[type=blaze,limit=1] {CustomName:"\"友善的烈焰人\""}
 



// run particle minecraft:dust (R G B) (particle size) (blockx blocky blockz) (Spread) (Speed)(Count)