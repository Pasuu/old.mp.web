onEvent('recipes', e => {

e.forEachRecipe({ type: 'minecraft:crafting_shaped', output: '#minecraft:slabs' }, r => {
  e.shaped(r.inputItems[0], ["A", "A"], { A: r.outputItems[0].withCount(1) });
});

//Crafting
e.shaped('minecraft:netherrack', ['NN','NN'], {N: 'kubejs:netherrack_dust'}) 
e.shaped('versatileportals:portal_controller', [' P ','PWP',' P '], {P: 'versatileportals:portal_frame', W: 'versatileportals:empty_existing_world_control'})
e.shaped('minecraft:soul_sand', ['NN','NN'], {N: 'kubejs:soul_dust'})
e.shaped('kubejs:aqua_bricks', ['AA','AA'], {A: 'kubejs:aqua_ball'})
e.shaped('minecraft:crimson_nylium', ['F','N'], {N: 'minecraft:nether_wart_block', F: 'minecraft:crimson_fungus'})
e.shaped('minecraft:warped_nylium', ['F','N'], {N: 'minecraft:warped_wart_block', F: 'minecraft:warped_fungus'})
e.shaped('bloodmagic:altar', ['SNS','SBS','SGS'], {N: 'kubejs:netherrack_dust', S: 'quark:soul_sandstone', G: 'minecraft:glowstone', B: 'minecraft:bone'})
e.shaped('kubejs:quartz_cobalt_wand', ['  Q',' W ','C  '], {C: '#forge:ingots/cobalt', Q: '#forge:gems/quartz', W: '#infernopolis:advanced_wand'})
e.shaped('bloodmagic:sacrificialdagger', ['  N','BN ','SB '], {N: 'tconstruct:necrotic_bone', S: '#forge:rods/wooden', B: 'minecraft:bone'})
e.shaped('16x tconstruct:soul_glass_pane', ['GGG','GGG'], {G: 'tconstruct:soul_glass'})
e.shaped('kubejs:summoner_wand', [' S ','SWS', ' S '], {S: 'kubejs:activated_spawner_shard', W: '#infernopolis:quartz_cobalt_wand'})
e.shaped('kubejs:basic_wand', ['  G',' S ', 'S  '], {S: '#forge:rods/wooden', G: '#forge:dusts/glowstone'})
e.shaped(Item.of('custommachinery:custom_machine_item', {machine:"custommachinery:infuser"}), ['SSS','SCS', 'SSS'], {C: '#forge:storage_blocks/charcoal', S: 'kubejs:soul_dust'}).id('kubejs:infuser')
e.shaped('kubejs:sign', ['P','S'], {P: '#minecraft:planks', S: '#forge:rods/wooden'})
e.shaped('cobblefordays:tier_2', ['GGG','GCG', 'GGG'], {C: '#forge:cobblestone', G: 'cobblefordays:tier_1'})
e.shaped('cobblefordays:tier_3', ['GGG','GCG', 'GGG'], {C: '#forge:storage_blocks/iron', G: 'cobblefordays:tier_2'})
e.shaped('cobblefordays:tier_4', ['GGG','GCG', 'GGG'], {C: '#forge:storage_blocks/gold', G: 'cobblefordays:tier_3'})
e.shaped('cobblefordays:tier_5', ['GGG','GCG', 'GGG'], {C: '#forge:storage_blocks/diamond', G: 'cobblefordays:tier_4'})
e.shaped('calemiutils:market', ['SCS','SWS', 'SCS'], {S: 'minecraft:glowstone', C: 'calemiutils:coin_quarter', W: 'calemiutils:wallet'})
e.shaped('2x minecraft:arrow', ['F','S', 'L'], {F: 'minecraft:flint', S: '#forge:rods/wooden', L: '#minecraft:leaves'})
e.shaped('minecraft:chest', ['PPP','P P', 'PPP'], {P: '#minecraft:planks'})
e.shaped('constructionwand:stone_wand', ['  T',' S ', 'S  '], {S: '#forge:rods/wooden', T: '#forge:stone'})
e.shaped('constructionwand:stone_wand', ['  T',' S ', 'S  '], {S: '#forge:rods/wooden', T: 'minecraft:blackstone'})
e.shaped('minecraft:cornflower', ['LLL','LSL', 'LLL'], {S: '#forge:seeds', L: 'minecraft:blue_dye'})

e.shaped('goldenhopper:golden_hopper', ['G G','GHG', ' G '], {G: '#forge:ingots/gold', H: 'woodenhopper:wooden_hopper'})

e.shaped(Item.of('custommachinery:custom_machine_item', {machine:"custommachinery:ore_duplicator"}), ['SAS','TLG', 'SAS'], {T: '#tconstruct:tanks', S: '#tconstruct:scorched_blocks', A: '#forge:gems/aquamarine', L: 'bloodmagic:lavacrystal', G: '#tconstruct:casts/multi_use/ingot'}).id('kubejs:ore_duplicator')
e.shaped(Item.of('custommachinery:custom_machine_item', {machine:"custommachinery:organic_material_gen"}), ['SAS','TLT', 'SAS'], {T: '#tconstruct:tanks', A: '#tconstruct:scorched_blocks', S: '#forge:ingots/iron', L: 'minecraft:bucket'}).id('kubejs:organic_material_gen')

e.shapeless(item.of('minecraft:bone_meal', 6), ['3x #infernopolis:nether_fungus', 'tconstruct:ichor_slime_ball'])
e.shapeless(item.of('kubejs:soul_dust', 1), ['kubejs:netherrack_dust', 'minecraft:bone_meal'])


//Campfire
e.campfireCooking('quark:soul_sandstone', 'minecraft:soul_sand')
e.campfireCooking('tconstruct:necrotic_bone', 'minecraft:bone')
e.campfireCooking('minecraft:glowstone', 'minecraft:shroomlight')
e.campfireCooking('minecraft:charcoal', '#minecraft:logs')
e.campfireCooking('minecraft:mushroom_stew', 'farmersdelight:nether_salad')
e.campfireCooking('minecraft:leather', 'minecraft:rotten_flesh')

//Smelting
e.smelting('tconstruct:soul_glass', 'minecraft:soul_sand')
e.smelting('tconstruct:ichor_slime_dirt', 'tconstruct:ichor_congealed_slime')
e.smelting('minecraft:mushroom_stew', 'farmersdelight:nether_salad')

//Removed & Replaced
e.replaceInput({mod: 'botanypots'}, 'minecraft:hopper', 'woodenhopper:wooden_hopper')
e.replaceInput({mod: 'botanypots'}, 'minecraft:flower_pot', '#minecraft:mushroom_hyphae')
e.replaceInput({mod: 'botanypots'}, 'minecraft:white_terracotta', 'minecraft:bone_block')
e.replaceInput({id: 'tconstruct:tables/pattern'}, '#minecraft:planks', 'minecraft:oak_planks')
e.replaceInput({id: 'bloodmagic:alchemy_table'}, 'minecraft:gold_ingot', 'minecraft:glowstone_dust')
e.replaceInput({id: 'bloodmagic:alchemy_table'}, 'minecraft:iron_ingot', 'minecraft:glowstone')
e.replaceInput({id: 'bloodmagic:alchemy_table'}, '#forge:stone', 'quark:soul_sandstone')
e.replaceInput({id: 'bloodmagic:altar/slate'}, '#forge:stone', 'quark:soul_sandstone')
e.replaceInput({id: 'bloodmagic:alchemytable/arcane_ash'}, 'minecraft:redstone', 'kubejs:soul_dust')
e.replaceInput({id: 'bloodmagic:array/divinationsigil'}, 'minecraft:redstone', 'kubejs:soul_dust')
e.replaceInput({id: 'minecraft:nether_brick'}, 'minecraft:netherrack', 'kubejs:netherrack_dust')
e.replaceInput({id: 'bloodmagic:guide'}, 'minecraft:glass', 'tconstruct:soul_glass')
e.replaceInput({id: 'bloodmagic:blood_rune_speed'}, 'minecraft:sugar', 'minecraft:bone_meal')
e.replaceInput({id: 'farmersdelight:cutting_board'}, '#minecraft:planks', 'tconstruct:pattern')
e.replaceInput({id: 'bloodmagic:array/growthsigil'}, 'bloodmagic:reinforcedslate', 'bloodmagic:blankslate')
e.replaceInput({id: 'bloodmagic:altar/daggerofsacrifice'}, 'minecraft:iron_sword', 'bloodmagic:sacrificialdagger')
e.replaceInput({id: 'bloodmagic:altar/apprenticebloodorb'}, 'minecraft:redstone_block', 'tconstruct:blood_slime')
e.replaceInput({id: 'bloodmagic:soul/forge'}, 'bloodmagic:blankslate', 'bloodmagic:infusedslate')
e.replaceInput({id: 'bloodmagic:soulforge/pettytartaricgem'}, '#forge:gems/lapis', 'tconstruct:cobalt_ingot')
e.replaceInput({id: 'bloodmagic:soulforge/pettytartaricgem'}, '#forge:dusts/redstone', 'minecraft:iron_ingot')
e.replaceInput({id: 'bloodmagic:soulforge/commontartaricgem'}, '#forge:storage_blocks/gold', '#forge:storage_blocks/queens_slime')
e.replaceInput({id: 'bloodmagic:soulforge/lessertartaricgem'}, '#forge:storage_blocks/lapis', '#forge:storage_blocks/quartz')
e.replaceInput({id: 'bloodmagic:soulforge/lessertartaricgem'}, 'minecraft:diamond', 'tconstruct:ichor_slime_ball')
e.replaceInput({id: 'bloodmagic:soulforge/lessertartaricgem'}, '#forge:storage_blocks/redstone', '#forge:storage_blocks/pig_iron')
e.replaceInput({id: 'bloodmagic:soulforge/commontartaricgem'}, 'minecraft:diamond', '#forge:storage_blocks/gold')
e.replaceInput({id: 'bloodmagic:soulforge/sentientsword'}, 'minecraft:iron_sword', 'tconstruct:sword')
e.replaceInput({id: 'bloodmagic:soulforge/sentientshovel'}, 'minecraft:iron_shovel', 'tconstruct:mattock')
e.replaceInput({id: 'bloodmagic:soulforge/sentientpickaxe'}, 'minecraft:iron_pickaxe', 'tconstruct:pickaxe')
e.replaceInput({id: 'bloodmagic:soulforge/sentientaxe'}, 'minecraft:iron_axe', 'tconstruct:hand_axe')
e.replaceInput({id: 'bloodmagic:soulforge/sentientscythe'}, 'minecraft:iron_axe', 'tconstruct:kama')
e.replaceInput({id: 'bloodmagic:array/night'}, 'minecraft:lapis_lazuli', 'kubejs:blood_diamond')
e.replaceInput({id: 'calemiutils:tools/wallet'}, 'minecraft:paper', 'calemiutils:coin_nickel')
e.replaceInput({mod: 'cobblefordays'}, '#minecraft:logs', 'woodenhopper:wooden_hopper')
e.replaceInput({mod: 'cobblefordays'}, 'minecraft:water_bucket', 'bloodmagic:reagentwater')
e.replaceInput({mod: 'cobblefordays'}, 'minecraft:lava_bucket', 'bloodmagic:reagentlava')
e.replaceInput({mod: 'cobblefordays'}, 'minecraft:glass', 'minecraft:cobblestone')
e.replaceInput({id: 'bloodmagic:soulforge/demon_crucible'}, 'minecraft:lapis_lazuli', 'kubejs:aqua_ball')
e.replaceInput({id: 'bloodmagic:soulforge/demon_crystallizer'}, 'minecraft:lapis_lazuli', 'kubejs:aqua_ball')
e.replaceInput({id: 'bloodmagic:alchemytable/reagent_water'}, 'minecraft:sugar', 'kubejs:aqua_ball')
e.replaceInput({id: 'versatileportals:portal_lighter'}, 'minecraft:lapis_lazuli', 'minecraft:gunpowder')
e.replaceInput({id: 'versatileportals:portal_lighter'}, 'minecraft:flint_and_steel', 'kubejs:advanced_wand')
e.replaceInput({id: 'storagedrawers:quantify_key'}, 'minecraft:writable_book', 'minecraft:name_tag')
e.replaceInput({id: 'farmersdelight:organic_compost_from_rotten_flesh'}, 'farmersdelight:straw', '#minecraft:saplings')
e.replaceInput({id: 'bloodmagic:alchemytable/reagent_fastminer'}, 'minecraft:iron_pickaxe', 'quark:pickarang')
e.replaceInput({id: 'bloodmagic:alchemytable/reagent_fastminer'}, 'minecraft:iron_shovel', 'astralsorcery:crystal_shovel')
e.replaceInput({id: 'bloodmagic:alchemytable/reagent_fastminer'}, 'minecraft:iron_axe', 'bloodmagic:soulaxe')
//Occultism

e.custom({"type": "occultism:spirit_fire","ingredient": {"tag": "minecraft:logs"},"result": {"item": "occultism:otherworld_log"}})
e.custom({
    "type": "occultism:ritual",
    "activation_item": {
      "item": "occultism:book_of_binding_bound_foliot"
    },
    "pentacle_id": "occultism:summon_foliot",
    "require_item_use": false,
    "require_sacrifice": false,
    "ritual": {
      "item": "occultism:ritual_dummy/summon_foliot_crusher"
    },
    "ingredients": [
      {
        "tag": "forge:ores"
      },
      {
        "tag": "forge:ores"
      },
      {
        "tag": "forge:ores"
      },
      {
        "tag": "forge:ores"
      }
    ],
    "result": {
      "item": "occultism:jei_dummy/none"
    }
  }).id('occultism:ritual/summon_foliot_crusher')
//Blood Magic
e.custom({"type": "bloodmagic:array","texture": "bloodmagic:textures/models/alchemyarrays/divinationsigil.png","baseinput": {"item": 'minecraft:gunpowder'},"addedinput": {"item": 'kubejs:basic_wand'},"output": {"item": 'kubejs:advanced_wand'}})
//e.custom({"type": "bloodmagic:array","texture": "bloodmagic:textures/models/alchemyarrays/divinationsigil.png","baseinput": {"item": 'minecraft:book'},"addedinput": {"item": 'bloodmagic:blankrune'},"output": {"item": 'mana-and-artifice:guide_book'}})

onEvent('recipes', event => {
const { altar, array, soulforge, arc, alchemytable } = event.recipes.bloodmagic
altar('tconstruct:blood_slime_ball', 'tconstruct:ichor_slime_ball').altarSyphon(200)
altar('minecraft:gunpowder', 'tconstruct:necrotic_bone').altarSyphon(200)
altar('bloodmagic:weakbloodorb', 'tconstruct:blood_congealed_slime').altarSyphon(2000).id('bloodmagic:altar/weakbloodorb')
altar('minecraft:quartz', '#forge:storage_blocks/quartz').altarSyphon(100)
altar('minecraft:iron_ingot', 'minecraft:quartz').altarSyphon(2000).upgradeLevel(2)
altar('minecraft:name_tag', 'minecraft:book').altarSyphon(200).upgradeLevel(2)
altar('kubejs:activated_spawner_shard', 'kubejs:spawner_shard').altarSyphon(8000).upgradeLevel(3)
altar('kubejs:blood_diamond', '#forge:storage_blocks/cobalt').altarSyphon(5000).upgradeLevel(3)
altar('astralsorcery:aquamarine', 'astralsorcery:aquamarine_sand_ore').altarSyphon(5000).upgradeLevel(3)
altar('tconstruct:copper_ingot', '#forge:ingots/gold').altarSyphon(500).upgradeLevel(1)
altar('tconstruct:copper_ore', '#forge:ores/gold').altarSyphon(750).upgradeLevel(1)
altar('tconstruct:seared_stone', 'minecraft:blackstone').altarSyphon(300).upgradeLevel(1)

arc('minecraft:sand', 'minecraft:soul_sand', 'kubejs:aqua_ball')
arc('minecraft:diamond', 'kubejs:blood_diamond', 'kubejs:aqua_ball')
arc('minecraft:red_sand', 'minecraft:soul_sand', 'tconstruct:blood_slime_ball')

alchemytable('minecraft:furnace', ['minecraft:blackstone', 'minecraft:blackstone', 'minecraft:blackstone', 'minecraft:blackstone', 'minecraft:blackstone', 'minecraft:blackstone'])
alchemytable('minecraft:oak_sapling', ['minecraft:dirt', 'minecraft:warped_fungus'])
alchemytable('2x tconstruct:seared_brick', ['minecraft:blackstone', 'minecraft:flint', 'minecraft:magma_cream'])
alchemytable('tconstruct:seared_drain', ['tconstruct:seared_brick', 'tconstruct:seared_brick', 'tconstruct:seared_brick', 'tconstruct:seared_brick','tconstruct:seared_brick', 'tconstruct:seared_faucet']).id('tconstruct:smeltery/seared/chute')
alchemytable('tconstruct:seared_duct', ['tconstruct:seared_brick', 'tconstruct:seared_brick', 'tconstruct:cobalt_ingot', 'tconstruct:cobalt_ingot','#forge:ingots/cobalt', '#forge:ingots/cobalt']).id('tconstruct:smeltery/seared/duct')
alchemytable('tconstruct:seared_chute', ['tconstruct:seared_brick', 'tconstruct:seared_brick', 'tconstruct:seared_brick', 'tconstruct:seared_brick','tconstruct:seared_brick', '#forge:chests/wooden']).id('tconstruct:smeltery/seared/drain')
alchemytable('tconstruct:seared_melter', ['tconstruct:seared_brick', 'tconstruct:seared_brick', 'tconstruct:seared_brick', 'tconstruct:seared_brick', 'tconstruct:seared_brick', 'tconstruct:soul_glass']).syphon(2000).ticks(1000).id('tconstruct:smeltery/seared/melter')
alchemytable('tconstruct:seared_heater', ['tconstruct:seared_brick', 'tconstruct:seared_brick', 'tconstruct:seared_brick', 'tconstruct:seared_brick', 'tconstruct:seared_brick', 'quark:charcoal_block']).syphon(2000).ticks(1000).id('tconstruct:smeltery/seared/heater')
alchemytable('bloodmagic:reagentlava', ['quark:charcoal_block', 'minecraft:blaze_rod', 'minecraft:blaze_rod', 'minecraft:magma_block', 'minecraft:blaze_rod', 'minecraft:blaze_rod']).syphon(2000).ticks(1000).id('bloodmagic:alchemytable/reagent_lava')
alchemytable('bloodmagic:reagentgrowth', ['#minecraft:saplings', '#minecraft:saplings', '#minecraft:saplings', '#minecraft:saplings', 'minecraft:bone_block', 'minecraft:bone_block']).syphon(2000).ticks(1000).id('bloodmagic:alchemytable/reagent_growth')
alchemytable('bloodmagic:ironsand', ['minecraft:quartz', 'minecraft:quartz', 'minecraft:sand', 'minecraft:sand', 'minecraft:sand', 'minecraft:sand']).syphon(2000).ticks(1000).upgradeLevel(2)
alchemytable('kubejs:magical_dust', ['#forge:gunpowder', '#forge:dusts/glowstone', 'kubejs:netherrack_dust', 'kubejs:soul_dust']).syphon(1000).ticks(1000).upgradeLevel(2)
alchemytable('astralsorcery:aquamarine_sand_ore', ['minecraft:sand', 'kubejs:aqua_ball', 'kubejs:aqua_ball', 'kubejs:aqua_ball', 'kubejs:aqua_ball', 'kubejs:aqua_ball']).syphon(3000).ticks(1000).upgradeLevel(4)
alchemytable('astralsorcery:altar_discovery', ['#forge:marble', '#forge:marble', '#forge:marble', '#forge:marble', 'astralsorcery:liquid_starlight_bucket', '#forge:workbenches']).syphon(2000).ticks(1000).upgradeLevel(4)

})

//Custom Machine

onEvent('recipes', event => {
event.recipes.custommachinery.custom_machine("custommachinery:infuser", 100)
.requireItem('minecraft:cracked_nether_bricks', 'input1')
.requireItem('minecraft:cracked_nether_bricks', 'input4')
.requireItem('tconstruct:soul_glass', 'input2')
.requireItem('tconstruct:soul_glass', 'input3')
.requireItem('versatileportals:empty_existing_world_control', 'input5')
.produceItem(Item.of('versatileportals:existing_world_control', {RepairCost:0,WorldID:"infernopolis:ghast_lands",display:{Name:"{\"text\":\"恶魂之地宝石\"}"},Color:11943875}))
})

onEvent('recipes', event => {
event.recipes.custommachinery.custom_machine("custommachinery:infuser", 100)
.requireItem('minecraft:dragon_head', 'input1')
.requireItem('quark:myalite_crystal', 'input4')
.requireItem('tconstruct:ender_slime_bucket', 'input2')
.requireItem('minecraft:shulker_shell', 'input3')
.requireItem('versatileportals:empty_existing_world_control', 'input5')
.produceItem(Item.of('versatileportals:existing_world_control', {RepairCost:0,WorldID:"minecraft:overworld",display:{Name:"{\"text\":\"主世界？\"}"},Color:3669742}))
})

onEvent('recipes', event => {
event.recipes.custommachinery.custom_machine("custommachinery:infuser", 100)
.requireItem('minecraft:gilded_blackstone', 'input1')
.requireItem('minecraft:gilded_blackstone', 'input4')
.requireItem('tconstruct:obsidian_pane', 'input2')
.requireItem('kubejs:blood_diamond', 'input3')
.requireItem('versatileportals:empty_existing_world_control', 'input5')
.produceItem(Item.of('versatileportals:existing_world_control', {RepairCost:0,WorldID:"infernopolis:nether_islands",display:{Name:"{\"text\":\"下界群岛宝石\"}"},Color:13772502}))
})

onEvent('recipes', event => {
event.recipes.custommachinery.custom_machine("custommachinery:infuser", 100)
.requireItem('astralsorcery:starmetal_ingot', 'input1')
.requireItem('astralsorcery:starmetal_ingot', 'input4')
.requireItem('kubejs:aqua_bricks', 'input2')
.requireItem('kubejs:aqua_bricks', 'input3')
.requireItem('versatileportals:empty_existing_world_control', 'input5')
.produceItem(Item.of('versatileportals:existing_world_control', {RepairCost:0,WorldID:"infernopolis:seaopolis",display:{Name:"{\"text\":\"海之城宝石\"}"},Color:7308118}))
})

onEvent('recipes', event => {
event.recipes.custommachinery.custom_machine("custommachinery:infuser", 100)
.requireItem('astralsorcery:black_marble_bricks', 'input1')
.requireItem('astralsorcery:black_marble_bricks', 'input4')
.requireItem('astralsorcery:liquid_starlight_bucket', 'input2')
.requireItem('astralsorcery:liquid_starlight_bucket', 'input3')
.requireItem('versatileportals:empty_existing_world_control', 'input5')
.produceItem(Item.of('versatileportals:existing_world_control', {WorldID:"infernopolis:the_missing_world",display:{Name:"{\"text\":\"消失世界宝石\"}"},Color:9531362}))
})

onEvent('recipes', event => {
event.recipes.custommachinery.custom_machine("custommachinery:infuser", 100)
.requireItem('calemiutils:raritanium', 'input1')
.requireItem('calemiutils:raritanium', 'input4')
.requireItem('calemiutils:raritanium', 'input2')
.requireItem('calemiutils:raritanium', 'input3')
.requireItem('versatileportals:empty_existing_world_control', 'input5')
.produceItem(Item.of('versatileportals:existing_world_control', {display:{Name:"{\"text\":\"末地宝石\"}"},Color:13024191,WorldID:"minecraft:the_end"}))
})

//Astral

//Rock Crystal Ore
e.custom({"type": "astralsorcery:altar","altar_type": 0,"duration": 200,"starlight": 300,"pattern": [
"_____",
"_SAS_",
"_ALA_",
"_SAS_",
"_____"],
"key": {"A": {"tag": "forge:gems/aquamarine"}, "S": {"tag": "forge:stone"}, "L": {"item": "astralsorcery:liquid_starlight_bucket"}},"output":[{"item": 'astralsorcery:rock_crystal_ore',"count": 1}],"effects":["astralsorcery:built_in_effect_discovery_central_beam"]})

//Collector Crystal (CAP STARLIGHT 2000)
e.custom({"type": "astralsorcery:altar","altar_type": 1,"duration": 300,"starlight": 1800,"pattern": [
"L___L",
"_RRR_",
"_RAR_",
"_RRR_",
"L___L"],
"key": {"A": {"tag": "forge:gems/aquamarine"},"L": {"item": 'astralsorcery:illumination_powder'},"R": {"item": "astralsorcery:rock_crystal"}},"output":[{"item":"astralsorcery:rock_collector_crystal","count":1,"nbt":"{astralsorcery:{constellation:\"astralsorcery:discidia\",crystalProperties:{attributes:[{property:\"astralsorcery:size\",pLevel:1,discovered:1b},{property:\"astralsorcery:purity\",pLevel:1,discovered:1b},{property:\"astralsorcery:shape\",pLevel:1,discovered:1b},{property:\"astralsorcery:collector.rate\",pLevel:1,discovered:1b},{property:\"astralsorcery:constellation.discidia\",pLevel:2,discovered:1b}]}}}"}],"effects": ["astralsorcery:built_in_effect_discovery_central_beam","astralsorcery:built_in_effect_attunement_sparkle"]})

//Constilation Papers
e.custom({"type": "astralsorcery:altar","altar_type": 1,"duration": 300,"starlight": 600,"pattern": [
"P___P",
"_A_A_",
"__B__",
"_A_A_",
"P___P"],
"key": {"A": {"tag": "forge:gems/aquamarine"},"P": {"item": 'astralsorcery:parchment'},"B": {"item": "minecraft:book"}},"output":[{"item": "astralsorcery:constellation_paper","count": 1}],"effects": ["astralsorcery:built_in_effect_discovery_central_beam","astralsorcery:built_in_effect_attunement_sparkle"]})

//Unpowered Starmetal Ore
e.custom({"type": "astralsorcery:altar","altar_type": 1,"duration": 300,"starlight": 1000,"pattern": [
"S___S",
"_VMV_",
"_MMM_",
"_VMV_",
"S___S"],
"key": {"S": {"item": "minecraft:stone"},"V": {"tag": 'forge:ingots/iron'},"M": {"item": 'kubejs:magical_dust'}},"output":[{"item": 'kubejs:unpowered_starmetal_ore',"count": 1}],"effects": ["astralsorcery:built_in_effect_discovery_central_beam","astralsorcery:built_in_effect_attunement_sparkle"]})

//New Starmetal Ore
e.custom({"type": "astralsorcery:block_transmutation","input": [{"block": 'kubejs:unpowered_starmetal_ore',"display": {"item": 'kubejs:unpowered_starmetal_ore',"count": 1}}],"output": {"block": "astralsorcery:starmetal_ore"},"display": {"item": "astralsorcery:starmetal_ore","count": 1},"starlight": 700.0}).id('astralsorcery:block_transmutation/iron_starmetal')

//PSI

e.custom({"type": "psi:trick_crafting","input": {"item": "kubejs:magical_dust"},"output": {"item": "psi:psidust"},"cad":{"item": "psi:cad_assembly_iron"}}).id('psi:psidust')


//Tinkers (Smeltery)

e.custom({"type": "tconstruct:casting_basin","cast": {"item": "tconstruct:seared_heater"},"cast_consumed": true,"fluid": {"name": "tconstruct:seared_stone","amount": 1296},"result": "tconstruct:smeltery_controller","cooling_time": 100}).id('tconstruct:smeltery/casting/seared/smeltery_controller')
e.custom({"type": "tconstruct:casting_basin","cast": {"item": "tconstruct:seared_melter"},"cast_consumed": true,"fluid": {"name": "tconstruct:seared_stone","amount": 1296},"result": 'tconstruct:seared_fuel_tank',"cooling_time": 100}).id('tconstruct:smeltery/seared/fuel_tank')

//Tinkers (Melting)

e.custom({"type": "tconstruct:melting","ingredient": {"tag": "forge:gems/aquamarine"},"result": {"fluid": "astralsorcery:liquid_starlight","amount": 500},"temperature": 1000,"time": 100})
e.custom({"type": "tconstruct:melting","ingredient": {"item": "farmersdelight:organic_compost"},"result": {"fluid": "kubejs:organic_fluid","amount": 100},"temperature": 100,"time": 75})

//Tinkers (Misc Cast)

e.custom({"type": "tconstruct:casting_table","cast": {"item": 'minecraft:blackstone' },"cast_consumed": true,"fluid": {"name": "tconstruct:molten_gold","amount": 288},"result": 'minecraft:gilded_blackstone',"cooling_time": 80})
e.custom({"type": "tconstruct:casting_table","cast": {"item": 'minecraft:glass_bottle' },"cast_consumed": true,"fluid": {"name": "minecraft:water","amount": 100},"result": {"item": "minecraft:potion", "nbt": "{\"Potion\": \"minecraft:water\"}"}, "cooling_time": 80})
e.custom({"type": "tconstruct:casting_basin","fluid": {"name": "minecraft:milk","amount": 250},"result": 'astralsorcery:marble_raw',"cooling_time": 100})
e.custom({"type": "tconstruct:casting_basin","cast": {"item": 'minecraft:stone' },"cast_consumed": true,"fluid": {"name": "tconstruct:molten_quartz","amount": 144},"result": 'minecraft:andesite',"cooling_time": 75})

//Tinkers (Starmetal)

e.custom({"type": "tconstruct:melting","ingredient": {"item": 'astralsorcery:starmetal_ore'},"result": {"fluid": "kubejs:starmetal","amount": 288},"temperature": 1000,"time": 120})
e.custom({"type": "tconstruct:melting","ingredient": {"item": 'astralsorcery:starmetal_ingot'},"result": {"fluid": "kubejs:starmetal","amount": 144},"temperature": 1000,"time": 120})
e.custom({"type": "tconstruct:melting","ingredient": {"item": 'astralsorcery:starmetal'},"result": {"fluid": "kubejs:starmetal","amount": 1296},"temperature": 1000,"time": 200})
e.custom({"type": "tconstruct:casting_table","cast": {"tag": 'tconstruct:casts/multi_use/ingot' },"cast_consumed": false,"fluid": {"name": "kubejs:starmetal","amount": 144},"result": 'astralsorcery:starmetal_ingot',"cooling_time": 75})
e.custom({"type": "tconstruct:casting_table","cast": {"tag": 'tconstruct:casts/single_use/ingot' },"cast_consumed": true,"fluid": {"name": "kubejs:starmetal","amount": 144},"result": 'astralsorcery:starmetal_ingot',"cooling_time": 75})
e.custom({"type": "tconstruct:casting_basin","fluid": {"name": "kubejs:starmetal","amount": 1296},"result": 'astralsorcery:starmetal',"cooling_time": 120})

//Tinkers (Water)

e.custom({"type": "tconstruct:melting","ingredient": {"tag": "minecraft:saplings"},"result": {"fluid": "minecraft:water","amount": 10},"temperature": 0,"time": 10})
e.custom({"type": "tconstruct:melting","ingredient": {"tag": "minecraft:leaves"},"result": {"fluid": "minecraft:water","amount": 10},"temperature": 0,"time": 10})
e.custom({"type": "tconstruct:melting","ingredient": {"item": 'kubejs:aqua_ball'},"result": {"fluid": "minecraft:water","amount": 100},"temperature": 0,"time": 10})
e.custom({"type": "tconstruct:casting_table","cast": {"tag": 'tconstruct:casts/multi_use/gem' },"cast_consumed": false,"fluid": {"name": "minecraft:water","amount": 100},"result": 'kubejs:aqua_ball',"cooling_time": 30})
e.custom({"type": "tconstruct:casting_table","cast": {"tag": 'tconstruct:casts/single_use/gem' },"cast_consumed": true,"fluid": {"name": "minecraft:water","amount": 100},"result": 'kubejs:aqua_ball',"cooling_time": 30})

//Blood To Blood
e.custom({"type": "tconstruct:alloy",
  "inputs": [
    {
      "tag": "minecraft:water",
      "amount": 100
    },
    {
      "tag": "tconstruct:blood",
      "amount": 100
    }
  ],
  "result": {
    "fluid": "bloodmagic:life_essence_fluid",
    "amount": 200
  },
  "temperature": 605
})

//Remove (Output)
e.remove({output: [
'quark:soul_sandstone',
'minecraft:campfire',
'minecraft:ender_eye',
'minecraft:soul_campfire',
'minecraft:wooden_sword',
'minecraft:wooden_shovel',
'minecraft:wooden_hoe',
'minecraft:wooden_pickaxe',
'minecraft:wooden_axe',
'minecraft:stone_sword',
'minecraft:stone_shovel',
'minecraft:stone_hoe',
'minecraft:stone_pickaxe',
'minecraft:stone_axe',
'minecraft:gold_axe',
'minecraft:gold_pickaxe',
'minecraft:gold_hoe',
'minecraft:gold_shovel',
'minecraft:gold_sword',
'bloodmagic:altar',
'bloodmagic:sacrificialdagger',
'minecraft:flint',
'minecraft:diamond_axe',
'minecraft:diamond_pickaxe',
'minecraft:diamond_hoe',
'minecraft:diamond_shovel',
'minecraft:diamond_sword',
'minecraft:iron_axe',
'minecraft:iron_pickaxe',
'minecraft:iron_hoe',
'minecraft:iron_shovel',
'minecraft:iron_sword',
'minecraft:netherite_axe',
'minecraft:netherite_pickaxe',
'minecraft:netherite_hoe',
'minecraft:netherite_shovel',
'minecraft:netherite_sword',
'minecraft:bucket',
'tconstruct:crafting_station',
'cobblefordays:tier_2',
'cobblefordays:tier_3',
'cobblefordays:tier_4',
'cobblefordays:tier_5',
'calemiutils:link_book_location',
'calemiutils:market',
'minecraft:brewing_stand',
'goldenhopper:golden_hopper'

]})

//Remove (ID + Type)
e.remove({type: 'minecraft:smelting', input: '#forge:ores'})
e.remove({type: 'minecraft:blasting', input: '#forge:ores'})
e.remove({id:'tconstruct:smeltery/seared/seared_bricks_from_brick'})
e.remove({id:'tconstruct:smeltery/seared/seared_bricks'})
e.remove({id:'bloodmagic:arc/reversion/apprentice_blood_orb'})
e.remove({id:'bloodmagic:arc/reversion/master_blood_orb'})
e.remove({id:'bloodmagic:arc/reversion/weak_blood_orb'})
e.remove({id:'bloodmagic:arc/reversion/magician_blood_orb'})
e.remove({id:'bloodmagic:alchemytable/leather_from_flesh'})
e.remove({id:'tconstruct:smeltery/melting/slime/blood/sapling'})
e.remove({id:'tconstruct:smeltery/scorched/scorched_brick'})
e.remove({id:'tconstruct:smeltery/melting/copper/smeltery_controller'})
e.remove({id:'tconstruct:smeltery/melting/copper/smeltery_io'})
e.remove({id:'minecraft:netherite_ingot'})
e.remove({id:'minecraft:book'})
e.remove({id:'calemiutils:coins/raritanium'})
e.remove({id:'calemiutils:coins/coin_penny_from_raritanium'})
e.remove({id:'minecraft:andesite'})
e.remove({id:'minecraft:diorite'})
e.remove({id:'minecraft:granite'})
e.remove({id:'tconstruct:smeltery/casting/quartz/diorite'})
e.remove({id:'tconstruct:smeltery/casting/quartz/granite'})    
e.remove({id:'astralsorcery:infuser/ender_pearl'})    
e.remove({id:'versatileportals:empty_existing_world_control'})    
e.remove({id:'versatileportals:portal_controller'})    
e.remove({id:'versatileportals:portal_frame'})
})