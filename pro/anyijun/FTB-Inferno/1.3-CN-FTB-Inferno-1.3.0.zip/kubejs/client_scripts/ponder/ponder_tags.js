onEvent("ponder.tag", (event) => {

    event.createTag("kubejs:basic_bases", "biomesoplenty:flesh", "Basic Bases.", "This section shows basic bases", [
        "biomesoplenty:flesh",
        "minecraft:obsidian",
        "tconstruct:piglin_head",
        "minecraft:crimson_door",

    ]);
});