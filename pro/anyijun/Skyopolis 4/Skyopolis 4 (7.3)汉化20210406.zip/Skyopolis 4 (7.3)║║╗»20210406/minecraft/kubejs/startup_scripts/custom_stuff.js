// priority: 0

console.info('Hello, World! (在启动过程中，你仅会在控制台中看到此行一次)')

events.listen('item.registry', event => {
  // Register new items here
  // event.create('example_item').displayName('Example Item')
event.create('mossy_pebble').displayName('苔卵石')
event.create('sky_bucks').displayName('天空币')
event.create('dirt_mulch').displayName('泥土覆盖物')
event.create('andesite_pebble').displayName('安山岩卵石')
event.create('granite_pebble').displayName('花岗岩卵石')
event.create('diorite_pebble').displayName('闪长岩卵石')
event.create('dust').displayName('灰')
event.create('tiny_torch').displayName('微型火把')
event.create('coal_dust').displayName('煤粉')
event.create('blank_token').displayName('空白徽章')
event.create('nether_token').displayName('下界徽章')
event.create('end_token').displayName('末地徽章')
event.create('dimensional_dungeon_token').displayName('维度地牢徽章')
event.create('diamond_ingot').displayName('钻石锭')
event.create('blank_singularity').displayName('空白奇点')
event.create('fluid_duplication_token').displayName('流体复制徽章')
event.create('honey_token').displayName('蜂蜜徽章')
event.create('twilight_token').displayName('暮色徽章')
event.create('blank_spawn_egg').displayName('空白刷怪蛋')
event.create('dye_cluster').displayName('染料花簇').glow(true)
event.create('rune_of_absolute_power').displayName('绝对权力符文').glow(true)
})

events.listen('block.registry', event => {
  // Register new blocks here

  event.create('blank_ore').material('rock').hardness(1.0).displayName('空白矿石').requiresTool(true)
    

})

events.listen('fluid.registry', event => {
  event.create('organic_fluid').textureThick(0x86A774).displayName('有机水').bucketColor(0x86A774) 
  event.create('weak_eroding_fluid').textureThick(0x392C4C).displayName('弱蚀水').bucketColor(0x392C4C)
  event.create('weak_enriching_fluid').textureThick(0xD79113).displayName('弱富集水').bucketColor(0xD79113)
  event.create('strong_enriching_fluid').textureThick(0x808080).displayName('强富集水').bucketColor(0x808080)
  event.create('nether_enriching_fluid').textureThick(0x580704).displayName('下界富集水').bucketColor(0x580704)
  event.create('end_enriching_fluid').textureThick(0xD9E0A4).displayName('末地富集水').bucketColor(0xD9E0A4)
  event.create('ore_fluid').textureThick(0x44DCFF).displayName('成矿水').bucketColor(0x44DCFF)
  event.create('creosote_fluid').textureThick(0x7F2300).displayName('强力杂酚油').bucketColor(0x7F2300)
  event.create('magical_water').textureThick(0x00FF21).displayName('魔法水').bucketColor(0x00FF21)
})