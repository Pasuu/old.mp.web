events.listen('jei.information', function (event) {

  // Recipe JEI

event.add('bhc:red_heart', '从友好生物掉落')
event.add('bhc:yellow_heart', '从敌对生物掉落')
event.add('bhc:green_heart', '从下界的敌对生物掉落')
event.add('bhc:blue_heart', '从类似于末影龙或凋零这种boss生物掉落')
event.add('wstweaks:fragment', '从凋灵骷髅掉落')
event.add('quark:backpack', '确保在制作新背包之前先清空旧背包，否则会丢失物品。')
event.add('travelersbackpack:standard', '确保在制作新背包之前先清空旧背包，否则会丢失物品。')
event.add('create:shadow_steel', '将异彩化合物扔到虚空中，然后等待。你会看到暗影钢从虚空中升起')
event.add('create:refined_radiance', '将异彩化合物扔到信标光柱中，然后等待。你会看到光辉石从中升起')

})


 // Tool Tip JEI

onEvent('item.tooltip', event => {

event.add('bhc:red_heart', [Text.of('从友好生物掉落')])
event.add('bhc:yellow_heart', [Text.of('从敌对生物掉落')])
event.add('bhc:green_heart', [Text.of('从下界的敌对生物掉落')])
event.add('bhc:blue_heart', [Text.of('从类似于末影龙或凋零这种boss生物掉落')])
event.add('wstweaks:fragment', [Text.of('从凋灵骷髅掉落')])
event.add('pneumaticcraft:amadron_tablet', [Text.of('每天都去商店看看不同的东西！')])
event.add('apotheosis:boss_summoner', [Text.of('由此产生的一些小怪很难杀死，并且可能会破坏你的基地！')])
event.add('woodenutilities:wooden_shears', [Text.of('销毁这些剪刀，用新的').red()])
event.add('woodenutilities:wooden_hopper', [Text.of('销毁这些漏斗，用新的').red()])

})

//Hide JEI Items

onEvent('jei.hide.items', event => {

event.hide('cyclic:heart')
event.hide('cyclic:heart_empty')
event.hide('immersiveengineering:ingot_copper')
event.hide('immersiveengineering:ingot_lead')
event.hide('immersiveengineering:ingot_electrum')
event.hide('bno:aluminum_ingot')
event.hide('immersiveengineering:ingot_constantan')

})

