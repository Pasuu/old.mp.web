<!-- markdownlint-disable MD033 -->
# Chroma Endless

[![Chroma-Endless](https://img.shields.io/badge/CurseForge-Chroma--Endless-F16436)](https://www.curseforge.com/minecraft/modpacks/chroma-endless)
[![Website](https://shields.io/website?up_message=anyijun.com&url=http://anyijun.com&label=Website)](http://anyijun.com)
[![License](https://img.shields.io/badge/License-CC%20BY--NC--ND%204.0-blue)](https://github.com/ShaBaiTianCN/Chroma-Endless/blob/master/LICENSE)
[![Downloads](https://shields.io/github/downloads/ShaBaiTianCN/Chroma-Endless/total?label=Downloads)](https://github.com/ShaBaiTianCN/Chroma-Endless/releases)
[![Release](https://shields.io/github/v/release/ShaBaiTianCN/Chroma-Endless?display_name=tag&include_prereleases&label=Release)](https://github.com/ShaBaiTianCN/Chroma-Endless/releases/latest)

## 仓库说明

这里是 Chroma Endless 整合包简体中文汉化仓库。

## 作者

- [Ricky-fight](https://github.com/Ricky-fight)
- [AnzhiZhang](https://github.com/AnzhiZhang)
- [nai200](https://github.com/nai200)
- [Cactusstudent](https://github.com/Cactusstudent)
- [KlparetlR](https://github.com/KlparetlR)
- [bilibiliHaifu](https://github.com/bilibiliHaifu)
- [reallyhotice](https://github.com/reallyhotice)
- [Kanzaki-snail](https://github.com/Kanzaki-snail)
- [invisibility233](https://github.com/invisibility233)
- [xinyihl](https://github.com/xinyihl)
- [SipengXie](https://github.com/SipengXie)
- [2D6-Lir732613](https://github.com/2D6-Lir732613)
- [MeMoXrisE](https://github.com/MeMoXrisE)
- [233lailai](https://github.com/233lailai)
- [Shengxiaomoyu-ForesT](https://github.com/Shengxiaomoyu-ForesT)
- [mmoyuin](https://github.com/mmoyuin)
- [inomo](https://github.com/inomo)

## 安装

![汉化补丁食用说明](汉化补丁食用说明.jpg)

## 许可

<a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/4.0/"><img alt="知识共享许可协议" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-nd/4.0/88x31.png" /></a><br />本作品采用<a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/4.0/">知识共享署名-非商业性使用-禁止演绎 4.0 国际许可协议</a>进行许可。
