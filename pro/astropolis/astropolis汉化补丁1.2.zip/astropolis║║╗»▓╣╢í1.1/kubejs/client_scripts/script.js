// priority: 0

console.info('Hello, World! (You will see this line every time client resources reload)')

JEIEvents.hideItems(event => {

	event.hide('immersiveengineering:mold_gear')
})