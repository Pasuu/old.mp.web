// priority: 0

console.info('Hello, World! (You will only see this line once in console, during startup)')

StartupEvents.registry('item', event => {
	// Register new items here
	// event.create('example_item').displayName('Example Item')
	
event.create('copper_coin').displayName('铜币').tooltip('通过完成任务书任务获取').rarity('uncommon')
event.create('iron_coin').displayName('铁币').tooltip('通过完成任务书任务获取').rarity('uncommon')
event.create('gold_coin').displayName('金币').tooltip('通过完成任务书任务获取').rarity('rare')
event.create('diamond_coin').displayName('钻石币').tooltip('通过完成任务书任务获取').rarity('epic')
event.create('netherite_coin').displayName('下界合金币').tooltip('通过完成任务书任务获取').rarity('epic')
event.create('monster_coin').displayName('怪物币')
event.create('nether_coin').displayName('下界币').tooltip('通过完成任务书下界章节获取').rarity('uncommon')

event.create('diamond_nugget').displayName('钻石粒')
event.create('emerald_nugget').displayName('绿宝石粒')

event.create('dreadnoughtbow').displayName('无畏之弓图标').tooltip('这个物品只是个图标，完整配方可以在战利品箱中发现')
event.create('mace').displayName('狼牙棒图标').tooltip('这个物品只是个图标，完整配方可以在战利品箱中发现')
event.create('halberd').displayName('长戟图标').tooltip('这个物品只是个图标，完整配方可以在战利品箱中发现')

event.create('coin_01').displayName('硬币')
event.create('coin_02').displayName('一对硬币')
event.create('coin_03').displayName('一叠硬币')
event.create('coin_04').displayName('许多硬币')
event.create('coin_05').displayName('一堆硬币')

event.create('medal').displayName('奖章').glow(true)
event.create('heart').displayName('心')

event.create('fox').displayName('赞助者图标')
event.create('kruscle').displayName('赞助者图标')
event.create('plua').displayName('赞助者图标')
event.create('crankonator').displayName('赞助者图标')
event.create('lexileexx').displayName('赞助者图标')
	
})

StartupEvents.registry('block', event => {
	// Register new blocks here
	// event.create('example_block').material('wood').hardness(1.0).displayName('Example Block')
})