# FTB-Continuum-Guidebook-Chinese-l10n

<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-sa/4.0/88x31.png" /></a><br />This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/">Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License</a>.
<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/"><img alt="知识共享许可协议" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-sa/4.0/88x31.png" /></a><br />本作品采用<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/">知识共享署名-非商业性使用-相同方式共享 4.0 国际许可协议</a>进行许可。

This branch is the **Chinese l10n** of the **Guidebook** for **FTB Continuum**. Now update to **1.3.1**. 

本分支为 **FTB Continuum** 整合包**任务书**的**简体中文本地化**。现已更新到 **1.3.1** 版本。

Courtesy of **[@waitLH](https://github.com/waitLH)** for **"Industrial Reborn" Quest Line**, **[@SPRshachuku](https://github.com/SPRshachuku)** for **"The Basis of All Alchemy" and "Obligatory Hoarding Quests" Quest Lines** and **[@idyllist123](https://github.com/idyllist123)** for **"The Final Frontier" Quest Line**. I really appreciate to them. 

鸣谢 **[@waitLH](https://github.com/waitLH)** 为 **"工业复兴"任务线**, **[@SPRshachuku](https://github.com/SPRshachuku)** 为 **"一切炼金术的基础"和"强制性囤积任务"任务线** 以及 **[@idyllist123](https://github.com/idyllist123)** 为 **"最后的疆域"任务线** 提供的帮助。由衷地感谢他们。
